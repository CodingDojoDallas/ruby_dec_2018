class UsersController < ApplicationController
  def new
  end

  def show
  end

  def edit
  end
end
