class SecretsController < ApplicationController
  def index
    @secrets = Secret.all
  end
  def create
    @secret = Secret.new(secret_params)
    if @secret.valid?
      @secret.save
      # puts "hello"
    else
      flash[:errors] = @secret.errors.full_messages
    end
    redirect_to "/users/#{session[:user_id]}"
  end

  def destroy
    Secret.find(params[:secret][:secret_id]).destroy
    redirect_to "/users/#{session[:user_id]}"
  end

  private
    def secret_params
      params[:secret][:user_id] = current_user.id
      # puts "secret params for user: #{params[:secret][:user_id]}"
      params.require(:secret).permit(:content, :user_id)
    end
end
