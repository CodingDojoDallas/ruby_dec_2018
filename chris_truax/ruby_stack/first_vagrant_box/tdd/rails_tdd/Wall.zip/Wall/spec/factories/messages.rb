FactoryBot.define do
  factory :message do
    content { "This is a valid message to Post" }
    user 
  end
end
