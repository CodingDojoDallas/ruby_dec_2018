FactoryBot.define do
  factory :user do
    name { "MyString" }
  end
end
