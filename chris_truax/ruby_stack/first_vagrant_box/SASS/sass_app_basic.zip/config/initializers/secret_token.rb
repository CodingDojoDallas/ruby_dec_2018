# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
SassApp::Application.config.secret_key_base = '20d0dde261f89994184806dabef05977da99e73599e3ef3d0fee59babe46d5fd80a0d95d08b56ca989542f8c842bb6d2ae0f3f77ac10839508e3dec578f041b3'
