class UsersController < ApplicationController
  def new
  end

  def show
    # @user = User.find(session[:user_id])
  end

  def edit
  end
end
